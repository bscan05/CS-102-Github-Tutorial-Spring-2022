package com.example.gym;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class join_session extends AppCompatActivity {

    String faci;
    String sport;
    public FirebaseDatabase sessionDatabase;
    public DatabaseReference reference;
    private RecyclerView rview;
    public ArrayList<session> sessions_arr_list;
    public ArrayList<session> temporary;
    private session_rv_adapter adapter;
    String sesss;
    ArrayList<session> bscan;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_join_session);
        Intent k = getIntent();

        //declaring database
        sessionDatabase = FirebaseDatabase.getInstance();
        reference = sessionDatabase.getReference("Realll");
        //arraylist for reading data from databse
        sessions_arr_list = new ArrayList<session>();
        bscan = new ArrayList<session>();


        //
        //
        //child event listener







        //indicating which sport and facility we are using
        faci = k.getStringExtra("Name of facility");
        sport = k.getStringExtra("Sports Name");

        //set settings for recycler view
        rview = findViewById(R.id.rv);
        rview.setHasFixedSize(true);
        rview.setLayoutManager(new LinearLayoutManager(this));

        //arraylist for joiners
        ArrayList<String> joiners = new ArrayList<>();
        joiners.add("22003479");

        //creating example sessions
        session sess1 = new session("ten","main","10:30",9,7,joiners,"1");
        session sess2 = new session("ten","main","11:30",9,7,joiners,"2");
        session sess3 = new session("ten","main","12:30",9,7,joiners,"3");

        sessions_arr_list.add(sess1);
        sessions_arr_list.add(sess2);
        sessions_arr_list.add(sess3);

        //reference.push().setValue(sessions_arr_list);

        //reading data from database
        /*
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                    Toast.makeText(join_session.this, snapshot.exists() + "as", Toast.LENGTH_SHORT).show();
                    sesss = Objects.requireNonNull(snapshot.getValue()).toString();
                    bscan = (ArrayList<session>) snapshot.getValue();

                    TextView txt = findViewById(R.id.textView3);
                    txt.setText(sesss);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(join_session.this, "fails", Toast.LENGTH_SHORT).show();
            }
        });
        */




        sessions_arr_list.add(new session("ten","main","14:30",bscan.size(),7,joiners,"1"));


        //adapter
        //adapter = new session_rv_adapter(this,sessions_arr_list);

        //rview.setAdapter(adapter);

    }

    public void stringtosession(String a){

    }

    @Override
    protected void onResume() {
        super.onResume();
        adapter = new session_rv_adapter(join_session.this,sessions_arr_list);

        rview.setAdapter(adapter);
    }
    @Override
    protected void onPause() {
        super.onPause();

    }

    @Override
    protected void onStart() {
        super.onStart();
        reference.addChildEventListener(new ChildEventListener() {
            @SuppressLint("NotifyDataSetChanged")
            @Override
            public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

                Toast.makeText(join_session.this, snapshot.exists() + "as", Toast.LENGTH_SHORT).show();
                sesss = Objects.requireNonNull(snapshot.getValue()).toString();

                bscan = (ArrayList<session>) snapshot.getValue();

                TextView txt = findViewById(R.id.textView3);
                txt.setText(sesss);



            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot snapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


    }
}