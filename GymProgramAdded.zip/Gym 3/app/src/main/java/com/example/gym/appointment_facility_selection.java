package com.example.gym;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class appointment_facility_selection extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_appointment_facility_selection);
    }

    public void openMainCampusActivity(View v){
        Intent i = new Intent(this, selection_of_sports.class);
        i.putExtra("Chooser", "main");
        startActivity(i);

    }

    public void openDormintoryActivity(View v){
        Intent i = new Intent(this, selection_of_sports.class);
        i.putExtra("Chooser", "dorm");
        startActivity(i);

    }

    public void openEastCampusActivity(View v){
        Intent i = new Intent(this, selection_of_sports.class);
        i.putExtra("Chooser", "east");
        startActivity(i);

    }


}