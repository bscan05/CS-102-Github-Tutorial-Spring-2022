package com.example.gym;

import android.util.Log;

import java.util.ArrayList;

public class fitnessProgram {
    private ArrayList<ArrayList<exerciseMoves>> program; // One element for one day(0. element = Monday, 1. element = Tuesday)
    private String programName;
    private final int noOfDays = 7;
// Constructor
    public fitnessProgram(ArrayList<ArrayList<exerciseMoves>> program, String programName) {

        this.programName = programName;
        if(program == null) {
            this.program = new ArrayList<ArrayList<exerciseMoves>>();
            for (int i = 0; i < noOfDays; i++) {
                Log.e("added", "day");
                this.program.add(new ArrayList<exerciseMoves>());
            }
        }
        else{
            this.program = program;
        }
    }
// Getters and Setters
    public ArrayList<ArrayList<exerciseMoves>> getProgram() {
        return program;
    }

    public void setProgram(ArrayList<ArrayList<exerciseMoves>> program) {
        this.program = program;
    }

    public String getProgramName() {
        return programName;
    }

    public void setProgramName(String programName) {
        this.programName = programName;
    }

}
