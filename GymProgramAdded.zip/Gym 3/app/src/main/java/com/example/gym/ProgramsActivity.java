package com.example.gym;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class
ProgramsActivity extends AppCompatActivity {
private User user;
private ArrayList<fitnessProgram> usersPrograms;
private String usersProgramsJson;
private RecyclerView rv;
private programAdapter adapter;
private TextView numberOfPrograms;
private ImageButton addProgram;
private String usersUid;
private FirebaseDatabase database;
private DatabaseReference reference;
    /*fitnessProgram a = new fitnessProgram(null, "Definition");
    fitnessProgram b = new fitnessProgram(null, "Bulk");
    fitnessProgram c = new fitnessProgram(null, " Sport");
    fitnessProgram d = new fitnessProgram(null, " Sportss");
    fitnessProgram e = new fitnessProgram(null, " Football");*/
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.programs_activity);
        Log.e("eroor","!!!!!!!");
        usersUid = getIntent().getStringExtra("uid");
        Log.e("uid", usersUid);
        database = FirebaseDatabase.getInstance();
        reference = database.getReference("Userss");

        Query q = reference.orderByChild("firebaseId").equalTo(usersUid);
        q.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                    Log.e("exist", "yes");
                    for (DataSnapshot d : snapshot.getChildren()) {

                        //user = d.getValue(User.class);
                        //Log.e("name", user.getName());
                        //usersProgramsJson = user.getjSon();
                        usersProgramsJson = d.child("jSon").getValue(String.class);
                        Log.e("jsoo", usersProgramsJson);



                    }
                    Gson converter = new Gson();
                    Type programsType = new TypeToken<ArrayList<fitnessProgram>>(){}.getType();
                    usersPrograms = converter.fromJson(usersProgramsJson, programsType);
                    //adapter.notifyDataSetChanged();


                numberOfPrograms.setText("You have " + usersPrograms.size() + " programs");
                adapter = new programAdapter(ProgramsActivity.this, usersPrograms);
                adapter.setUserUid(usersUid);
                rv.setAdapter(adapter);


                ItemTouchHelper itemTouchHelper = new ItemTouchHelper(new SwipeProgram(adapter));

                itemTouchHelper.attachToRecyclerView(rv);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });



        /*Gson converter = new Gson();
        Type programsType = new TypeToken<ArrayList<fitnessProgram>>(){}.getType();
        usersPrograms = converter.fromJson(usersProgramsJson, programsType);*/









        numberOfPrograms = findViewById(R.id.ProgramsTextView);
        addProgram = findViewById(R.id.imageButtonProgram);
        rv = findViewById(R.id.recyclerViewPrograms);
        rv.setHasFixedSize(true);
        rv.setLayoutManager(new StaggeredGridLayoutManager(1, StaggeredGridLayoutManager.VERTICAL));

        /*usersPrograms = new ArrayList<fitnessProgram>(); //Firebase
        usersPrograms.add(a);
        usersPrograms.add(b);
        usersPrograms.add(c);
        usersPrograms.add(d);
        usersPrograms.add(e);*/
        addProgram.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                View alertDesign = getLayoutInflater().inflate(R.layout.add_program_alert_view, null);
                EditText name = alertDesign.findViewById(R.id.EditTextProgramName);
                AlertDialog.Builder addProgramAlert = new AlertDialog.Builder(ProgramsActivity.this);
                addProgramAlert.setMessage("Enter the name of the program:");
                addProgramAlert.setView(alertDesign);
                addProgramAlert.setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        String nameOfTheNewProgram = name.getText().toString();
                        usersPrograms.add(new fitnessProgram(null, nameOfTheNewProgram));
                        Gson converter = new Gson();
                        usersProgramsJson = converter.toJson(usersPrograms);
                        Map<String, Object> updateJson = new HashMap<>();
                        updateJson.put("jSon", usersProgramsJson);





                        Toast.makeText(getApplicationContext(), "Saved", Toast.LENGTH_SHORT).show();
                        //adapter.notifyItemInserted(usersPrograms.size() - 1);
                        adapter.notifyDataSetChanged();
                        numberOfPrograms.setText("You have " + usersPrograms.size() + " programs");
                        reference.child(usersUid).updateChildren(updateJson);
                    }
                });
                addProgramAlert.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(getApplicationContext(), "Cancelled", Toast.LENGTH_SHORT).show();
                    }
                });
                addProgramAlert.create().show();
            }
        });
       /* if(usersPrograms == null){
                usersPrograms = new ArrayList<fitnessProgram>();
                usersPrograms.add(new fitnessProgram(null, "a"));
        }*/
        /*numberOfPrograms.setText("You have " + usersPrograms.size() + " programs");
        adapter = new programAdapter(this, usersPrograms);
        rv.setAdapter(adapter);
        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(new SwipeProgram(adapter));
        itemTouchHelper.attachToRecyclerView(rv);*/
    }
}