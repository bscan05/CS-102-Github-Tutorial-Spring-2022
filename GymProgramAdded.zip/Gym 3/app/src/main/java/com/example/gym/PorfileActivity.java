package com.example.gym;

import android.os.Bundle;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class PorfileActivity extends AppCompatActivity {
    String name;
    int age;
    int weight;
    ImageView badge;

    public void setName(String name){
        this.name=name;
    }
    public void setAge(int age){
        this.age=age;
    }
    public void setWeight(int weight){
        this.weight=weight;
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
    }

    ArrayList<ImageView> badges = new ArrayList<ImageView>();

}