package com.example.gym;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

public class loginActivity extends AppCompatActivity {

    private EditText editTextTextEmailAddressLogin;
    private EditText editTextPassword;
    private Button loginbutton;
    private ProgressBar progressBar;
    private FirebaseAuth mAuth;
    private FirebaseUser mUser;
    private FirebaseDatabase database;
    private FirebaseUser firebaseUser;
    private DatabaseReference reference;
    String uid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        Log.e("sa","saaaaaaa");
        editTextTextEmailAddressLogin=findViewById(R.id.editTextTextEmailAddressLogin);
        editTextPassword=findViewById(R.id.editTextPassword);
        loginbutton=findViewById(R.id.loginbutton);
        progressBar=findViewById(R.id.progressBar);
        mAuth=FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();
        reference = database.getReference("Userss");


        firebaseUser = mAuth.getCurrentUser(); // registered user

        if(firebaseUser == null){ // check if the user is valid

            Intent i = new Intent(loginActivity.this,MainActivity.class);
            startActivity(i);
            finish();
        }


        loginbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loginUser();
            }
        });
    }

    private void loginUser(){

        String email=editTextTextEmailAddressLogin.getText().toString();
        String userPassword=editTextPassword.getText().toString();

        Query q = reference.orderByChild("email").equalTo(email);//*******????????

        q.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot d: snapshot.getChildren()){
                    //Log.e("aaa","bbb");
                    uid = d.getKey();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        /*Log.e("uid", uid);
        Map<String, Object> idUpload = new HashMap<>();
        idUpload.put("firebaseId", uid);
        reference.child(uid).updateChildren(idUpload);*/

        mAuth.signInWithEmailAndPassword(email,userPassword).addOnCompleteListener(loginActivity.this,
                new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful()){
                            //User ab = new User("abc","def", 1,"ghj", "hgt");
                            //FirebaseDatabase.getInstance().getReference("Userss").child("LOfpWfzGQzLehJ3Lwd2UTqfofiJ3").setValue(ab);
                            Map<String, Object> idUpload = new HashMap<>();
                            idUpload.put("firebaseId", uid);
                            reference.child(uid).updateChildren(idUpload);
                            Intent i = new Intent(loginActivity.this,menu.class);



                            i.putExtra("uid",uid);
                            Log.e("uid", uid);
                            //Toast.makeText(loginActivity.this,"Welcome"+mUser.getDisplayName(),Toast.LENGTH_LONG).show();
                            startActivity(i);

                            finish();

                        }
                        else{
                            Toast.makeText(getApplicationContext(),task.getException().getMessage(),Toast.LENGTH_SHORT).show();
                        }
                    }

                });
    }
        /*String email=editTextTextEmailAddressLogin.getText().toString().trim();
        String password=editTextPassword.getText().toString();


        progressBar.setVisibility(View.VISIBLE);
        mAuth.signInWithEmailAndPassword(email,password).addOnSuccessListener(this, new OnSuccessListener<AuthResult>() {
            @Override
            public void onSuccess(AuthResult authResult) {
                mUser=mAuth.getCurrentUser();
                progressBar.setVisibility(View.GONE);
                //Toast.makeText(loginActivity.this,"Welcome"+mUser.getEmail(),Toast.LENGTH_LONG).show();
                startActivity(new Intent(loginActivity.this,menu.class));
            }
        }).addOnFailureListener(this, new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                progressBar.setVisibility(View.GONE);
                Toast.makeText(loginActivity.this,"Login process is not succesfull",Toast.LENGTH_LONG).show();
            }
        });
        /*if(task.isSuccessful())
        {
            progressBar.setVisibility(View.GONE);
            startActivity(new Intent(loginActivity.this,menu.class));
        }
        else{
            progressBar.setVisibility(View.GONE);
            Toast.makeText(loginActivity.this,"Login process is not succesfull",Toast.LENGTH_LONG).show();
        }*/



    private boolean bilkentMailChecker(String email){
        boolean check=true;
        int start=email.indexOf('@');
        if(!Patterns.EMAIL_ADDRESS.matcher(email).matches())
        {
            return false;
        }
        if(!email.substring(start).equals("@ug.bilkent.edu.tr"))
        {
            check=false;
        }
        return check;
    }
}