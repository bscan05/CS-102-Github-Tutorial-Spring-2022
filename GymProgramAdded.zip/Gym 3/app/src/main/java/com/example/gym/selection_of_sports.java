package com.example.gym;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class selection_of_sports extends AppCompatActivity {

    String facility;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selection_of_sports);
        Intent i = getIntent();
        facility = i.getStringExtra("Chooser");
    }

    //for tennis
    public void openSessionsTennis(View v){

        Intent p = new Intent(this,join_session.class);
        p.putExtra("Name of facility",facility);
        p.putExtra("Sports Name", "ten");
        startActivity(p);


    }

    //for basketball
    public void openSessionsBasket(View v){

        Intent p = new Intent(this,join_session.class);
        p.putExtra("Name of facility",facility);
        p.putExtra("Sports Name", "bask");
        startActivity(p);


    }

    public void openSessionsFitness(View v){

        Intent p = new Intent(this,join_session.class);
        p.putExtra("Name of facility",facility);
        p.putExtra("Sports Name","fit");
        startActivity(p);


    }

    public void openSessionsSquash(View v){

        Intent p = new Intent(this,join_session.class);
        p.putExtra("Name of facility",facility);
        p.putExtra("Sports Name","squash");
        startActivity(p);


    }

    public void openSessionsSwimming(View v){

        Intent p = new Intent(this,join_session.class);
        p.putExtra("Name of facility",facility);
        p.putExtra("Sports Name","swim");
        startActivity(p);


    }

    public void openSessionsFootball(View v){

        Intent p = new Intent(this,join_session.class);
        p.putExtra("Name of facility",facility);
        p.putExtra("Sports Name","foot");
        startActivity(p);


    }

    public void openVoleyball(View v){

        Intent p = new Intent(this,join_session.class);
        p.putExtra("Name of facility",facility);
        p.putExtra("Sports Name","vol");
        startActivity(p);


    }
    public void openSessionsTableTennis(View v){

        Intent p = new Intent(this,join_session.class);
        p.putExtra("Name of facility",facility);
        p.putExtra("Sports Name","table");
        startActivity(p);


    }
}