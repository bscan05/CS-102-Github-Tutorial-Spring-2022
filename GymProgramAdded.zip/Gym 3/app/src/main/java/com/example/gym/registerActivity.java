package com.example.gym;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;
import com.google.gson.Gson;

import java.util.ArrayList;

public class registerActivity extends AppCompatActivity  {

    private Button register_button;
    private EditText editTextEmailAddress;
    private EditText editTextTextPassword;
    private EditText editTextTextPassword2;
    private EditText editTextTextPersonName;
    private EditText editTextDate;
    private ProgressBar progressBar;

    private FirebaseAuth mAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        mAuth=FirebaseAuth.getInstance();


        register_button=findViewById(R.id.register_button);
        editTextEmailAddress=findViewById(R.id.editTextEmailAddress);
        editTextTextPassword=findViewById(R.id.editTextTextPassword);
        editTextTextPassword2=findViewById(R.id.editTextTextPassword2);
        editTextTextPersonName=findViewById(R.id.editTextTextPersonName);
        editTextDate=findViewById(R.id.editTextDate);
        progressBar=findViewById(R.id.progressBar);

        register_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                registerUser();
            }
        });
    }
    private void registerUser() {
        String email = editTextEmailAddress.getText().toString().trim();
        String password = editTextTextPassword.getText().toString();
        String passwordAgain = editTextTextPassword2.getText().toString();
        String name = editTextTextPersonName.getText().toString().trim();
        String id_number = editTextDate.getText().toString().trim();



        if (email.isEmpty()) {
            editTextEmailAddress.setError("Please insert your e-mail");
            editTextEmailAddress.requestFocus();
            return;
        }
        if(!bilkentMailChecker(email))
        {
            editTextEmailAddress.setError("You must register with your Bilkent mail address");
            editTextEmailAddress.requestFocus();
            return;
        }
        if (password.isEmpty()) {
            editTextTextPassword.setError("Please create a password");
            editTextTextPassword.requestFocus();
            return;
        }
        if (passwordAgain.isEmpty() || passwordAgain.equals(password) == false) {
            editTextTextPassword2.setError("Password is not matched");
            editTextTextPassword2.requestFocus();
            return;
        }

        if (name.isEmpty()) {
            editTextTextPersonName.setError("Name can not be empty");
            editTextTextPersonName.requestFocus();
            return;
        }
        if (id_number.isEmpty() || id_number.length() != 8) {
            editTextDate.setError("Invalid ID number");
            editTextDate.requestFocus();
            return;
        }
        progressBar.setVisibility(View.VISIBLE);
        mAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(this,new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {

                if (task.isSuccessful()) {
                    Log.e("aaa","bbbbb");
                    ArrayList<fitnessProgram> a = new ArrayList<fitnessProgram>();
                    Gson converter = new Gson();
                    String jSon = converter.toJson(a);
                    User x=new User(name,email,Integer.parseInt(id_number), jSon, password);
                    Toast.makeText(registerActivity.this,"You have succesfully registered",Toast.LENGTH_LONG).show();
                    FirebaseDatabase.getInstance().getReference("Userss").child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                            .setValue(x).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if(task.isSuccessful()){
                                progressBar.setVisibility(View.GONE);
                                Toast.makeText(registerActivity.this,"You have succesfully registered",Toast.LENGTH_LONG).show();
                                Intent newIntent=new Intent(registerActivity.this,loginActivity.class);

                                startActivity(newIntent);

                            }
                            else{
                                progressBar.setVisibility(View.GONE);
                                Toast.makeText(registerActivity.this,"Registering process is not succesfull",Toast.LENGTH_LONG).show();

                            }
                        }
                    });
                }
                else{
                    progressBar.setVisibility(View.GONE);
                    Toast.makeText(registerActivity.this,"Registering process is not succesfull",Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    private boolean bilkentMailChecker(String email){
        boolean check=true;
        int start=email.indexOf('@');
        if(!Patterns.EMAIL_ADDRESS.matcher(email).matches())
        {
            return false;
        }
        if(!email.substring(start).equals("@ug.bilkent.edu.tr"))
        {
            check=false;
        }
        return check;
    }
}
