package com.example.gym;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class session_rv_adapter extends RecyclerView.Adapter<session_rv_adapter.CardViewDesignObjectsHolder> {

    private Context mContext;
    private List<session> sessions_list;

    public session_rv_adapter(Context mContext, List<session> sessions_list) {
        this.mContext = mContext;
        this.sessions_list = sessions_list;
    }

    public class CardViewDesignObjectsHolder extends RecyclerView.ViewHolder{

        public TextView variable_hour;
        public TextView variable_capacity;
        public TextView variable_remain;
        public CardView satır_session_card_view;

        public CardViewDesignObjectsHolder(View view){
            super(view);
            variable_hour = view.findViewById(R.id.variable_hour);
            variable_capacity = view.findViewById(R.id.variable_capacity);
            variable_remain = view.findViewById(R.id.variable_remain);
            satır_session_card_view  = view.findViewById(R.id.satır_session_card_view);
        }

    }

    @NonNull
    @Override
    public CardViewDesignObjectsHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.sessions_card_view,parent,false);
        return new CardViewDesignObjectsHolder(itemView);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull CardViewDesignObjectsHolder holder, int position) {
        session temp = sessions_list.get(position);

        holder.variable_hour.setText(temp.getTime());
        holder.variable_remain.setText(Integer.toString(temp.getRemain()));
        holder.variable_capacity.setText(Integer.toString(temp.getCapacity()));

        holder.satır_session_card_view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(mContext, "Sport: " + temp.getSport() + " Facility: "+ temp.getFaci(),Toast.LENGTH_LONG).show();
            }
        });



    }

    @Override
    public int getItemCount() {
        return sessions_list.size();
    }



}
