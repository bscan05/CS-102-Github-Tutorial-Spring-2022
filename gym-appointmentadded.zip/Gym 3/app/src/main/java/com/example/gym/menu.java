package com.example.gym;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class menu extends AppCompatActivity {
    public String usersUid;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        usersUid = getIntent().getStringExtra("uid");
    }

    public void openAppointment(View v){
        Intent i = new Intent(this,appointment_facility_selection.class);
        startActivity(i);
    }

    public void openFitnessProgram(View v){
        Intent i = new Intent(this,ProgramsActivity.class);
        i.putExtra("uid", usersUid);
        startActivity(i);
    }

    public void openProfile(View v){
        Intent i = new Intent(this,PorfileActivity.class);
        startActivity(i);
    }

}