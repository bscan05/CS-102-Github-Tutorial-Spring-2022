package com.example.gym;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class DaysAdapter extends RecyclerView.Adapter<DaysAdapter.DaysAdapterHolder>{
    private Context mContext;
    private ArrayList<ArrayList<exerciseMoves>> program;
    private String userUid;
    private int posOfProgram;

    public DaysAdapter(Context mContext, ArrayList<ArrayList<exerciseMoves>> program) {
        this.mContext = mContext;
        this.program = program;
    }
    public class DaysAdapterHolder extends RecyclerView.ViewHolder{
        CardView daysCard;
        ImageView imageViewDayCardView;
        TextView textViewDayCardView;
        TextView DaysCardViewTextViewNoOfExercises;
        public DaysAdapterHolder(View view){
            super(view);
            daysCard = view.findViewById(R.id.daysCardView);
            imageViewDayCardView = view.findViewById(R.id.imageViewDayCardView);
            textViewDayCardView = view.findViewById(R.id.textViewDayCardView);
            DaysCardViewTextViewNoOfExercises = view.findViewById(R.id.DaysCardViewTextViewNoOfExercises);

        }
    }
    @NonNull
    @Override
    public DaysAdapterHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.days_cardview, parent, false);
        return new DaysAdapterHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull DaysAdapterHolder holder, int position) {
        int pos = holder.getAdapterPosition();
        switch(position){
            case 0:
                holder.textViewDayCardView.setText("Monday");
                break;
            case 1:
                holder.textViewDayCardView.setText("Tuesday");
                break;
            case 2:
                holder.textViewDayCardView.setText("Wednesday");
                break;
            case 3:
                holder.textViewDayCardView.setText("Thursday");
                break;
            case 4:
                holder.textViewDayCardView.setText("Friday");
                break;
            case 5:
                holder.textViewDayCardView.setText("Saturday");
                break;
            case 6:
                holder.textViewDayCardView.setText("Sunday");
                break;
        }
        holder.DaysCardViewTextViewNoOfExercises.setText(program.get(position).size() + " exercises");
        holder.daysCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent goToViewSportsActivity = new Intent(mContext, viewSportsActivity.class);
                goToViewSportsActivity.putExtra("uid", userUid);
                goToViewSportsActivity.putExtra("posOfProgram", posOfProgram);
                goToViewSportsActivity.putExtra("posOfDay", pos);
                mContext.startActivity(goToViewSportsActivity);
            }
        });
    }

    @Override
    public int getItemCount() {
        return program.size();

    }

    public void setUserUid(String userUid) {
        this.userUid = userUid;
    }

    public void setPosOfProgram(int posOfProgram) {
        this.posOfProgram = posOfProgram;
    }
}
