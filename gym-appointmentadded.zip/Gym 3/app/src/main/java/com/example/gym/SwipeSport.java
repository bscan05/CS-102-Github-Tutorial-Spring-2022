package com.example.gym;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.RecyclerView;

public class SwipeSport extends ItemTouchHelper.SimpleCallback {
    sportAdapter msportAdapter;
    public SwipeSport(sportAdapter sportAdapter){
        super(0, ItemTouchHelper.LEFT);
        msportAdapter = sportAdapter;
    }
    @Override
    public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
        return false;
    }

    @Override
    public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
        int pos = viewHolder.getAdapterPosition();
        msportAdapter.deleteSport(pos);
    }
}
