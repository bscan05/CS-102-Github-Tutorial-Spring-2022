package com.example.gym;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class SwipeProgram extends ItemTouchHelper.SimpleCallback {
    programAdapter mprogramAdapter;
    private ArrayList<fitnessProgram> usersPrograms;
    public SwipeProgram(programAdapter programAdapter){
        super(0, ItemTouchHelper.LEFT);
        mprogramAdapter = programAdapter;
    }

    @Override
    public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
        return false;
    }

    @Override
    public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
        int pos = viewHolder.getAdapterPosition();
        mprogramAdapter.deleteProgram(pos);

    }

    public void setUsersPrograms(ArrayList<fitnessProgram> usersPrograms) {
        this.usersPrograms = usersPrograms;
    }
}
