package com.example.gym;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class join_session extends AppCompatActivity {

    String faci;
    String sport;
    public FirebaseDatabase sessionDatabase;
    public DatabaseReference reference;
    private RecyclerView rview;
    public ArrayList<Sesion> sessions_arr_list;
    public ArrayList<Sesion> temporary;
    private session_rv_adapter adapter;
    String sesss;
    ArrayList<Sesion> bscan;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_join_session);
        Intent k = getIntent();

        //declaring database
        sessionDatabase = FirebaseDatabase.getInstance();



        //arraylist for reading data from databse
        sessions_arr_list = new ArrayList<>();
        bscan = new ArrayList<Sesion>();


        //indicating which sport and facility we are using
        faci = k.getStringExtra("Name of facility");
        sport = k.getStringExtra("Sports Name");

        //set settings for recycler view
        rview = findViewById(R.id.rv);
        rview.setHasFixedSize(true);
        rview.setLayoutManager(new LinearLayoutManager(this));

        //arraylist for joiners
        ArrayList<String> joiners = new ArrayList<>();
        joiners.add("22003479");


        //reference = sessionDatabase.getReference("All_Sessions").child(faci).child(sport);

        //creating example sessions
        //Sesion sess1 = new Sesion(sport,faci,"09:00",16,joiners,"");
        //Sesion sess2 = new Sesion(sport,faci,"10:30",16,joiners,"");
        //Sesion sess3 = new Sesion(sport,faci,"12:00",16,joiners,"");
        //Sesion sess4 = new Sesion(sport,faci,"13:30",16,joiners,"");
        ///Sesion sess5 = new Sesion(sport,faci,"15:00",16,joiners,"");
        //Sesion sess6 = new Sesion(sport,faci,"16:30",16,joiners,"");
        //Sesion sess7 = new Sesion(sport,faci,"18:00",16,joiners,"");
        //Sesion sess8 = new Sesion(sport,faci,"19:30",16,joiners,"");


        //sessions_arr_list.add(sess1);
        //sessions_arr_list.add(sess2);
        //sessions_arr_list.add(sess3);


        //reference.push().setValue(sess1);
        //reference.push().setValue(sess2);
        //reference.push().setValue(sess3);
        //reference.push().setValue(sess4);
        //reference.push().setValue(sess5);
        //reference.push().setValue(sess6);
        //reference.push().setValue(sess7);
        //reference.push().setValue(sess8);



        DatabaseReference okuma = sessionDatabase.getReference("All_Sessions").child(faci).child(sport);


        //reading data from database

        okuma.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                bscan.clear();
                Iterable<DataSnapshot> keys = snapshot.getChildren();
                for (DataSnapshot key:keys) {
                    bscan.add(key.getValue(Sesion.class));
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        //for turning it to session String
        //sesss = Objects.requireNonNull(snapshot.getValue()).toString();
        //TextView txt = findViewById(R.id.textView3);
        //txt.setText(sesss);



        sessions_arr_list.add(new Sesion("ten","main","14:30",9,joiners,"1"));


        //adapter
        adapter = new session_rv_adapter(this,bscan);

        rview.setAdapter(adapter);

    }

    public void stringtosession(String a){

    }

    /*
        @Override
        protected void onResume() {
            super.onResume();
            adapter = new session_rv_adapter(join_session.this,sessions_arr_list);

            rview.setAdapter(adapter);
        }
        @Override
        protected void onPause() {
            super.onPause();

        }

    */
    @Override
    protected void onStart() {
        super.onStart();
        adapter.notifyDataSetChanged();


    }


}