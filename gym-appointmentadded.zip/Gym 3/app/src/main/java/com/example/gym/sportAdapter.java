package com.example.gym;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.FirebaseDatabase;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class sportAdapter extends RecyclerView.Adapter<sportAdapter.sportObjectsHolder>{
    private Context mContext;
    private ArrayList<exerciseMoves> exercises;
    private String userUid;
    private ArrayList<fitnessProgram> programs;
    private int posOfProgram,posOfDay;
    private boolean changeHappened;

    public sportAdapter(Context mContext, ArrayList<exerciseMoves> exercises) {
        this.mContext = mContext;
        this.exercises = exercises;
    }
    public class sportObjectsHolder extends RecyclerView.ViewHolder{
        CardView sportCard;
        TextView sportName;
        TextView sportCardText;
        TextView weightText;
        ImageView sportCardImage;
        ImageButton editSport;
        public sportObjectsHolder(View view){
            super(view);
            sportCard = view.findViewById(R.id.sportCard);
            sportName = view.findViewById(R.id.textViewSportName);
            sportCardText = view.findViewById(R.id.sportcardtext);
            weightText = view.findViewById(R.id.weighttext);
            sportCardImage = view.findViewById(R.id.sportCardImage);
            editSport = view.findViewById(R.id.imageButtonEditSport);
            changeHappened = false;
        }

    }
    @NonNull
    @Override
    public sportObjectsHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.sport_card_view, parent, false);
        return new sportObjectsHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull sportObjectsHolder holder, int position) {
        int pos = holder.getAdapterPosition();
        String nameofTheExercise = exercises.get(pos).getName();
        String repAndSet = exercises.get(pos).getRepetition() + " X " + exercises.get(pos).getSet();
        String weigth = exercises.get(pos).getWeight() + " kg";
        holder.sportName.setText(nameofTheExercise);
        holder.sportCardText.setText(repAndSet);
        holder.weightText.setText(weigth);
        boolean clicked = false;
        holder.editSport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                changeHappened = false;
                PopupMenu popup = new PopupMenu(mContext, holder.editSport);
                popup.getMenuInflater().inflate(R.menu.edit_exercise_menu, popup.getMenu());
                popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem menuItem) {
                        View alertDesign = LayoutInflater.from(mContext).inflate(R.layout.add_program_alert_view, null);
                        EditText input = alertDesign.findViewById(R.id.EditTextProgramName);
                        AlertDialog.Builder editExerciseAlert = new AlertDialog.Builder(mContext);
                        editExerciseAlert.setView(alertDesign);
                        if(menuItem.getItemId() == R.id.actionEditName){
                            editExerciseAlert.setMessage("Edit the name of the exercise");
                            editExerciseAlert.setPositiveButton("Save", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    String newName = input.getText().toString();
                                    exercises.get(pos).setName(newName);
                                    programs.get(posOfProgram).getProgram().get(posOfDay).get(pos).setName(newName);
                                    Gson converter = new Gson();
                                    String jSon = converter.toJson(programs);
                                    Map<String, Object> updateJson = new HashMap<>();
                                    updateJson.put("jSon", jSon);
                                    FirebaseDatabase.getInstance().getReference("Userss").child(userUid).updateChildren(updateJson);
                                    changeHappened = true;
                                    Toast.makeText(mContext, "Name changed: " + newName, Toast.LENGTH_SHORT).show();
                                    notifyItemChanged(pos);
                                }
                            });
                                editExerciseAlert.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                        Toast.makeText(mContext, "Cancelled" , Toast.LENGTH_SHORT).show();
                                    }
                                });
                        }
                        else if(menuItem.getItemId() == R.id.actionEditRep){
                            editExerciseAlert.setMessage("Edit the repetition of the exercise");
                            editExerciseAlert.setPositiveButton("Save", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    Integer newRep = Integer.parseInt(input.getText().toString());
                                    exercises.get(pos).setRepetition(newRep);
                                    programs.get(posOfProgram).getProgram().get(posOfDay).get(pos).setRepetition(newRep);
                                    Gson converter = new Gson();
                                    String jSon = converter.toJson(programs);
                                    Map<String, Object> updateJson = new HashMap<>();
                                    updateJson.put("jSon", jSon);
                                    FirebaseDatabase.getInstance().getReference("Userss").child(userUid).updateChildren(updateJson);
                                    changeHappened = true;
                                    Toast.makeText(mContext, "Rep changed: " + newRep, Toast.LENGTH_SHORT).show();
                                    notifyItemChanged(pos);
                                }
                            });
                            editExerciseAlert.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    Toast.makeText(mContext, "Cancelled" , Toast.LENGTH_SHORT).show();
                                }
                            });
                        }
                        else if(menuItem.getItemId() == R.id.actionEditSet){
                            editExerciseAlert.setMessage("Edit the set of the exercise");
                            editExerciseAlert.setPositiveButton("Save", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    Integer newSet = Integer.parseInt(input.getText().toString());
                                    exercises.get(pos).setSet(newSet);
                                    programs.get(posOfProgram).getProgram().get(posOfDay).get(pos).setSet(newSet);
                                    Gson converter = new Gson();
                                    String jSon = converter.toJson(programs);
                                    Map<String, Object> updateJson = new HashMap<>();
                                    updateJson.put("jSon", jSon);
                                    FirebaseDatabase.getInstance().getReference("Userss").child(userUid).updateChildren(updateJson);
                                    changeHappened = true;
                                    Toast.makeText(mContext, "Set changed: " + newSet, Toast.LENGTH_SHORT).show();
                                    notifyItemChanged(pos);
                                }
                            });
                            editExerciseAlert.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    Toast.makeText(mContext, "Cancelled" , Toast.LENGTH_SHORT).show();
                                }
                            });
                        }
                        else if(menuItem.getItemId() == R.id.actionEditWeight){
                            editExerciseAlert.setMessage("Edit the weight of the exercise");
                            editExerciseAlert.setPositiveButton("Save", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    Integer newWeight = Integer.parseInt(input.getText().toString());
                                    exercises.get(pos).setWeight(newWeight);
                                    programs.get(posOfProgram).getProgram().get(posOfDay).get(pos).setWeight(newWeight);
                                    Gson converter = new Gson();
                                    String jSon = converter.toJson(programs);
                                    Map<String, Object> updateJson = new HashMap<>();
                                    updateJson.put("jSon", jSon);
                                    FirebaseDatabase.getInstance().getReference("Userss").child(userUid).updateChildren(updateJson);
                                    changeHappened = true;
                                    Toast.makeText(mContext, "Weight changed: " + newWeight, Toast.LENGTH_SHORT).show();
                                    notifyItemChanged(pos);
                                }
                            });
                            editExerciseAlert.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    Toast.makeText(mContext, "Cancelled" , Toast.LENGTH_SHORT).show();
                                }
                            });
                        }
                        editExerciseAlert.create().show();
                        return false;
                    }
                });
                popup.show();





            }
            //notifyItemChanged(pos);
        });
    }

    @Override
    public int getItemCount() {
        return exercises.size();
    }

    public void deleteSport(int i){
        exercises.remove(i);
        programs.get(posOfProgram).getProgram().get(posOfDay).remove(i);
        Gson converter = new Gson();
        String jSon = converter.toJson(programs);
        Map<String, Object> updateJson = new HashMap<>();
        updateJson.put("jSon", jSon);
        FirebaseDatabase.getInstance().getReference("Userss").child(userUid).updateChildren(updateJson);




        notifyDataSetChanged();
    }

    public void setUserUid(String userUid) {
        this.userUid = userUid;
    }

    public void setPrograms(ArrayList<fitnessProgram> programs) {
        this.programs = programs;
    }

    public void setPosOfProgram(int posOfProgram) {
        this.posOfProgram = posOfProgram;
    }

    public void setPosOfDay(int posOfDay) {
        this.posOfDay = posOfDay;
    }
}
